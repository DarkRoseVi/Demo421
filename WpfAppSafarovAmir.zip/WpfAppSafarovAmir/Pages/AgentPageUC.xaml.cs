﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppSafarovAmir.DataBase;
using WpfAppSafarovAmir.UserControlls;

namespace WpfAppSafarovAmir.Pages
{
    /// <summary>
    /// Логика взаимодействия для AgentPageUC.xaml
    /// </summary>
    public partial class AgentPageUC : Page
    {
        private List<Agent> _agents;
        private List<AgentType> _agentTypes;
        private int _currentPage;
        private int PageSize = 10;

        public AgentPageUC()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {

            _agents = App.DB.Agent.ToList();

            _agentTypes = App.DB.AgentType.ToList();
            _agentTypes.Insert(0, new AgentType { Title = "Все типы" });

            FilterCB.ItemsSource = _agentTypes;
            FilterCB.DisplayMemberPath = "Title";
            FilterCB.SelectedIndex = 0;
            SortCB.SelectedIndex = 0;

            UpdateAgentsListView();

        }

        private void UpdateAgentsListView()
        {
            List<Agent> filteredAgents = _agents;

            if (FilterCB.SelectedIndex > 0)
            {
                var selectedType = (AgentType)FilterCB.SelectedItem;
                filteredAgents = filteredAgents.Where(a => a.AgentTypeID == selectedType.ID).ToList();
            }

            filteredAgents = SearchByINputField(filteredAgents);

            switch (((ComboBoxItem)SortCB.SelectedItem)?.Content.ToString())
            {
                case "По наименованию (возр.)":
                    filteredAgents = filteredAgents.OrderBy(a => a.Title).ToList();
                    break;
                case "По наименованию (убыв.)":
                    filteredAgents = filteredAgents.OrderByDescending(a => a.Title).ToList();
                    break;
                case "По скидке (возр.)":
                    filteredAgents = filteredAgents.OrderBy(a => CalculateDiscount(a)).ToList();
                    break;
                case "По скидке (убыв.)":
                    filteredAgents = filteredAgents.OrderByDescending(a => CalculateDiscount(a)).ToList();
                    break;
                case "По приоритету (возр.)":
                    filteredAgents = filteredAgents.OrderBy(a => a.Priority).ToList();
                    break;
                case "По приоритету (убыв.)":
                    filteredAgents = filteredAgents.OrderByDescending(a => a.Priority).ToList();
                    break;
                case "По умолчанию":
                    filteredAgents = SearchByINputField(_agents);
                    break;

            }

            var pagedAgents = filteredAgents.Skip((_currentPage - 1) * PageSize).Take(PageSize).ToList();


            AgentWrap.Children.Clear();

            var productsToShow = filteredAgents
                .Skip(_currentPage * PageSize)
                .Take(PageSize)
                .ToList();

            foreach (var product in productsToShow)
            {
                AgentWrap.Children.Add(new AgentUserControll(product));
            }

            PageNumberTB.Text = $"Страница {_currentPage}";
        }

        private List<Agent> SearchByINputField(List<Agent> filteredAgents)
        {
            if (!string.IsNullOrEmpty(SearchTB.Text))
            {
                var searchText = SearchTB.Text.ToLower();
                filteredAgents = filteredAgents.Where(a => a.Title.ToLower().Contains(searchText) ||
                                                            a.Phone.ToLower().Contains(searchText) ||
                                                            a.Email.ToLower().Contains(searchText)).ToList();
            }

            return filteredAgents;
        }

        private decimal CalculateDiscount(Agent agent)
        {
            var totalSales = agent.ProductSale.Sum(ps => ps.ProductCount * ps.Product.MinCostForAgent);
            if (totalSales >= 500000) return 25;
            if (totalSales >= 150000) return 20;
            if (totalSales >= 50000) return 10;
            if (totalSales >= 10000) return 5;
            return 0;
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _currentPage = 1;
            UpdateAgentsListView();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _currentPage = 1;
            UpdateAgentsListView();
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _currentPage = 1;
            UpdateAgentsListView();
        }

        private void PrevPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage > 1)
            {
                _currentPage--;
                UpdateAgentsListView();
            }
        }

        private void NextPageButton_Click(object sender, RoutedEventArgs e)
        {
            _currentPage++;
            UpdateAgentsListView();
        }
    }
}

