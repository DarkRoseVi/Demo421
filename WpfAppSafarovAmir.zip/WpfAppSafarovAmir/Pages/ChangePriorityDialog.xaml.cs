﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppSafarovAmir.Pages
{
    /// <summary>
    /// Логика взаимодействия для ChangePriorityDialog.xaml
    /// </summary>
    public partial class ChangePriorityDialog : Window
    {
        public ChangePriorityDialog()
        {
            InitializeComponent();
        }

        public int NewPriority { get; private set; }

        public ChangePriorityDialog(int currentPriority)
        {
            Title = "Изменить приоритет";
            Width = 300;
            Height = 150;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            var stackPanel = new StackPanel { Margin = new Thickness(10) };

            var textBlock = new TextBlock { Text = "Новый приоритет:" };
            var textBox = new TextBox { Text = currentPriority.ToString() };
            var button = new Button { Content = "Изменить", Margin = new Thickness(0, 10, 0, 0) };

            button.Click += (s, e) =>
            {
                if (int.TryParse(textBox.Text, out int newPriority))
                {
                    NewPriority = newPriority;
                    DialogResult = true;
                }
                else
                {
                    MessageBox.Show("Введите корректное число.");
                }
            };

            stackPanel.Children.Add(textBlock);
            stackPanel.Children.Add(textBox);
            stackPanel.Children.Add(button);

            Content = stackPanel;
        }
    }
}
