﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using WpfAppSafarovAmir.DataBase;
using WpfAppSafarovAmir.Pages;

namespace WpfAppSafarovAmir.UserControlls
{
    /// <summary>
    /// Логика взаимодействия для AgentUserControll.xaml
    /// </summary>
    public partial class AgentUserControll : UserControl
    {
        private Agent _agent;
        public AgentUserControll(Agent agent)
        {
            _agent = agent;
            InitializeComponent();
            TypeCB.ItemsSource = App.DB.AgentType.ToList();
            TypeCB.DisplayMemberPath = "Title";
            UpdateData();
        }


        private void UpdateData()
        {

            TitleTB.Text = _agent.Title;
            FIOTB.Text = _agent.DirectorName;
            AddresTB.Text = _agent.Address;
            INNTB.Text = _agent.INN.ToString();
            KPPDP.Text = _agent.KPP.ToString();
            PhotoIMG.Source = GetimageSources(_agent.AgentBinary);
            EmailTB.Text = _agent.Email;
            PhoneNumberTB.Text = _agent.Phone;
            TypeCB.SelectedItem = _agent.AgentType;
            PriorityTB.Text = _agent.Priority.ToString();
        }

        private BitmapImage GetimageSources(byte[] byteImage)
        {
            if (byteImage != null)
            {
                MemoryStream memoryStream = new MemoryStream(byteImage);
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.StreamSource = memoryStream;
                image.EndInit();
                return image;
            }
            else
                return new BitmapImage(new Uri(@"\Resource\analys.png", UriKind.Relative));
        }


        private void EditImageBtn_Click(object sender, System.Windows.RoutedEventArgs e) =>
            EditImage();
        private void Interactable_LostFocus(object sender, System.Windows.RoutedEventArgs e) =>
            SaveChanges();

        private void EditImage()
        {
            OpenFileDialog openFile = new OpenFileDialog()
            {
                Filter = "*.png|*.png|All files (*.*)|*.*"
            };
            if (openFile.ShowDialog().GetValueOrDefault())
            {
                _agent.AgentBinary = File.ReadAllBytes(openFile.FileName);
                PhotoIMG.Source = new BitmapImage(new Uri(openFile.FileName)); ;
            }
            App.DB.SaveChanges();
        }


        private void SaveChanges()
        {
            _agent.Title = TitleTB.Text;
            _agent.AgentType = (TypeCB.SelectedItem as AgentType);
            _agent.Address = AddresTB.Text;
            _agent.INN = INNTB.Text;
            _agent.KPP = KPPDP.Text;
            _agent.DirectorName = FIOTB.Text;
            _agent.Phone = PhoneNumberTB.Text;
            _agent.Email = EmailTB.Text;
            _agent.Priority = int.Parse(PriorityTB.Text);
            App.DB.SaveChanges();
        }

        private void ChangePriorityButton_Click(object sender, RoutedEventArgs e)
        {
            CHangePrior();

        }

        private void CHangePrior()
        {
            ChangePriorityDialog dialog = new ChangePriorityDialog((int)_agent.Priority);
            if (dialog.ShowDialog() == true)
            {


                _agent.Priority = dialog.NewPriority;
                App.DB.AgentPriorityHistory.Add(new AgentPriorityHistory
                {
                    AgentID = _agent.ID,
                    ChangeDate = DateTime.Now,
                    PriorityValue = dialog.NewPriority
                });

                App.DB.SaveChanges();

                MainWindow.Current.Naviagate(new AgentPageUC());
            }
            UpdateData();
            SaveChanges();
            SaveChanges();
        }
    }
}
