﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppSafarovAmir.Pages;

namespace WpfAppSafarovAmir
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow Current { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            MainFrame.NavigationService.Navigate(new AgentPageUC());
            if(Current ==null)
                Current = this;
            else
                return;
            foreach (var item in App.DB.Agent.ToArray())
            {
                item.AgentBinary = File.ReadAllBytes("C:\\Users\\212116\\Desktop\\" + item.Logo);
            }
            App.DB.SaveChanges();
        }

        internal void Naviagate(Page clientServiceRegPage)
        {
            MainFrame.NavigationService.Navigate(clientServiceRegPage);
        }
    }
}
