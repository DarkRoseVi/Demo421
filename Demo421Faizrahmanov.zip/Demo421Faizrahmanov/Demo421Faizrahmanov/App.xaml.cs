﻿using Demo421Faizrahmanov.Bases;
using Demo421Faizrahmanov.Pages;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Demo421Faizrahmanov
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
       
        public static Demo_421_FaizrahmanovEntities db = new Demo_421_FaizrahmanovEntities();
        
    }
}
