﻿using Kalinina_Masha_421.Base;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kalinina_Masha_421
{
    /// <summary>
    /// Логика взаимодействия для AgentPage.xaml
    /// </summary>
    public partial class AgentPage : Page
    {
        public AgentPage()
        {
            InitializeComponent();
            Agent.ItemsSource = App.db.Agent.ToList();
            SortCb.SelectedIndex = 0;
        }
        private async void Refresh()
        {
            IEnumerable<Agent> items = App.db.Agent;

            if (SerchTB.Text != "")
                items = items.Where(x => x.Title.ToLower().Contains(SerchTB.Text.ToLower())
                    || x.Title.ToLower().Contains(SerchTB.Text.ToLower()));

            if (SortCb.SelectedIndex > 0)
            {
                if (SortCb.SelectedIndex == 1)
                    items = items.OrderBy(x => x.Title);
                else if (SortCb.SelectedIndex == 2)
                    items = items.OrderByDescending(x => x.Title);
            }

            Agent.ItemsSource = items.ToList();
        }

        private void SortCb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

        private void SerchTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void Del_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            
            
        }
    }
}
