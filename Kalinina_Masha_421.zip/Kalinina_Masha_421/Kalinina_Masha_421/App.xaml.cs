﻿using Kalinina_Masha_421.Base;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Kalinina_Masha_421
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Kalinina_Masha_421Entities db = new Kalinina_Masha_421Entities();
    }
}
