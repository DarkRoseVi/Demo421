﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace UchebkaExamShabaeva2802
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static ShabaevaAmina280225Entities db = new ShabaevaAmina280225Entities();
        public static MainWindow mainWindow;


    }
}
