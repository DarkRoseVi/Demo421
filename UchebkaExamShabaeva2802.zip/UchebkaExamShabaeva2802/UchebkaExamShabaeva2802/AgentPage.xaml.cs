﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UchebkaExamShabaeva2802
{
    /// <summary>
    /// Логика взаимодействия для AgentPage.xaml
    /// </summary>
    public partial class AgentPage : Page
    {
        public AgentPage()
        {
            InitializeComponent();
            SortCb.SelectedIndex = 0;
            ListLv.ItemsSource = App.db.Agent.ToList();
        }
        private async void Refresh()
        {
            IEnumerable<Agent> items = App.db.Agent.Where(x => x.ID != 0);

            if (SearchTb.Text != "")
                items = items.Where(x => x.Title.ToLower().Contains(SearchTb.Text.ToLower())
                    || x.Title.ToLower().Contains(SearchTb.Text.ToLower()));

            if (SortCb.SelectedIndex > 0)
            {
                if (SortCb.SelectedIndex == 1)
                    items = items.OrderBy(x => x.Title);
                else if (SortCb.SelectedIndex == 2)
                    items = items.OrderByDescending(x => x.Title);
            }

            ListLv.ItemsSource = items.ToList();
        }

        private void SortCb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

        private void SearchTb_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void ListLv_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            NavigationService.Navigate(new AddEditAgentPage(ListLv.SelectedItem as Agent));
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddAgentPage());
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
