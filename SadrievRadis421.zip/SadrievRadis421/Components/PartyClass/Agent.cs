﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SadrievRadis421.Components
{
    partial class Agent
    {
        public int SalesAmount {
            get
            {
                int sales = 0;
                DateTime prevYear = DateTime.Now.AddYears(-1);
                DateTime nextYear = DateTime.Now.AddYears(1);
                foreach (ProductSale ps in App.db.ProductSale.Where(x => x.AgentID == ID && x.SaleDate >= prevYear && x.SaleDate <= nextYear).ToList()) sales += ps.ProductCount;
                return sales;
            }   
        }
        public int Discount { get 
            {
                int percent = 0;
                if (SalesAmount < 10000) percent = 0;
                else if (SalesAmount <= 50000) percent = 5;
                else if (SalesAmount <= 15000) percent = 10;
                else if (SalesAmount <= 500000) percent = 20;
                else if (SalesAmount > 500000) percent = 25;
                return percent;
            }
        }
    }
}
