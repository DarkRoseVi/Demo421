﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SadrievRadis421.Components;

namespace SadrievRadis421.Pages
{
    /// <summary>
    /// Логика взаимодействия для AgentsListPage.xaml
    /// </summary>
    public partial class AgentsListPage : Page
    {
        public AgentsListPage()
        {
            InitializeComponent();
            Refresh();
            List<String> filters = new List<string>();
            filters.Add("Все типы");
            foreach (AgentType type in App.db.AgentType.ToList())
            {
                filters.Add(type.Title);
            }
            FiltrCbx.ItemsSource = filters;
        }

        public void Refresh()
        {
            AgentsWp.Children.Clear();
            PagesSP.Children.Clear();
            //PageCurrentTb.Text = "1";
            List<Agent> AgentsList = App.db.Agent.ToList();
            if (AgentsList.Count > 10)
            {
                int cunt = AgentsList.Count / 10;
                if (AgentsList.Count % 10 > 0) cunt = (AgentsList.Count / 10) + 1;
                for (int i = 0; i < cunt; i++)
                {
                    Button butt = new Button() { Content = (i + 1).ToString(), Height = 40, Width = 40, };
                    butt.Click += (sender, e) => { PageButt_Click(sender, e); };
                    PagesSP.Children.Add(butt);
                }
                AgentsList = AgentsList.Skip(10 * int.Parse(PageCurrentTb.Text)).Take(10).ToList();
            }

            if (AgentsList.Count != 0 && SortCbx.SelectedIndex != -1)
            {
                if (SortCbx.SelectedIndex == 0) AgentsList = AgentsList.OrderBy(x=>x.Title).ToList();
                else if (SortCbx.SelectedIndex == 1) AgentsList = AgentsList.OrderByDescending(x => x.Title).ToList();
                else if (SortCbx.SelectedIndex == 2) AgentsList = AgentsList.OrderBy(x => x.Discount).ToList();
                else if (SortCbx.SelectedIndex == 3) AgentsList = AgentsList.OrderByDescending(x => x.Discount).ToList();
                else if (SortCbx.SelectedIndex == 4) AgentsList = AgentsList.OrderBy(x => x.Priority).ToList();
                else if (SortCbx.SelectedIndex == 5) AgentsList = AgentsList.OrderByDescending(x => x.Priority).ToList();
            }

            if (FiltrCbx.SelectedIndex > 0)
            {
                if (FiltrCbx.SelectedIndex == 1) AgentsList = AgentsList.Where(x=>x.AgentTypeID == 1).ToList();
                else if (FiltrCbx.SelectedIndex == 2) AgentsList = AgentsList.Where(x => x.AgentTypeID == 2).ToList();
                else if (FiltrCbx.SelectedIndex == 3) AgentsList = AgentsList.Where(x => x.AgentTypeID == 3).ToList();
                else if (FiltrCbx.SelectedIndex == 4) AgentsList = AgentsList.Where(x => x.AgentTypeID == 4).ToList();
                else if (FiltrCbx.SelectedIndex == 5) AgentsList = AgentsList.Where(x => x.AgentTypeID == 5).ToList();
                else if (FiltrCbx.SelectedIndex == 6) AgentsList = AgentsList.Where(x => x.AgentTypeID == 6).ToList();
            }

            if (SearchTbx.Text != "") AgentsList = AgentsList.Where(x=>x.Title.ToLower().Contains(SearchTbx.Text.ToLower()) || x.Email.ToLower().Contains(SearchTbx.Text.ToLower()) || x.Phone.Contains(SearchTbx.Text)).ToList();

            foreach (Agent agent in AgentsList)
            {
                AgentsWp.Children.Add(new AgentUC(agent));
            }
        }

        private void PageButt_Click(object sender, RoutedEventArgs e)
        {
            PageCurrentTb.Text = (sender as Button).Content.ToString();
            Refresh();
        }

        private void BackButt_Click(object sender, RoutedEventArgs e)
        {
            if (PageCurrentTb.Text != "1")
            {
                PageCurrentTb.Text = (int.Parse(PageCurrentTb.Text) - 1).ToString();
            }
            Refresh();
        }

        private void ForwardButt_Click(object sender, RoutedEventArgs e)
        {

            PageCurrentTb.Text = (int.Parse(PageCurrentTb.Text) + 1).ToString();
            Refresh();
        }

        private void SortCbx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

        private void FiltrCbx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

        private void SearchTbx_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }
    }
}
