﻿using PrDemo.Pages;
using System.Windows;

namespace PrDemo
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Navigation.Initialize(this);
            Navigation.NextPage(new ProductList());
        }
    }
}
