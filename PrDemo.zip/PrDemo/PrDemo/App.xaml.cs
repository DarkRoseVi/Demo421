﻿using PrDemo.Databases;
using System.Windows;

namespace PrDemo
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static PrDemoEntities db = new PrDemoEntities();
    }
}
