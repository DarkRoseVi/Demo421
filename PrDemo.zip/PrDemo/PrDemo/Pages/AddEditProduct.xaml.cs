﻿using PrDemo.Databases;
using Microsoft.Win32;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PrDemo.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProduct.xaml
    /// </summary>
    public partial class AddEditProduct : Page
    {
        private Product Product { get; set; }
        public AddEditProduct(Product product)
        {
            InitializeComponent();
            Product = product;
            ProductTypeCb.ItemsSource = App.db.ProductType.ToList();


            DataContext = Product;
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            Navigation.BackPage();
        }

        private void ArticleTb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !new Regex(@"[0-9]").IsMatch(e.Text);
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ArticleTb.Text == "" || TitleTb.Text == "" || ProductTypeCb.SelectedIndex == -1 || MinCost.Text == "")
                {
                    MessageBox.Show("Заполните все данные!");
                    return;
                }

                if (ArticleTb.Text.Length < 6)
                {
                    MessageBox.Show("Артикль минимум 6 символов!");
                    return;
                }



                if (Product.ID == 0)
                    App.db.Product.Add(Product);
                App.db.SaveChanges();

                Navigation.NextPage(new ProductList());
                MessageBox.Show("Успешно сохранено!");
            }
            catch { MessageBox.Show("Неправильно ввели данные!"); }
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                if(ofd.ShowDialog() == true)
                {
                    Product.Photo = File.ReadAllBytes(ofd.FileName);
                    MyImage.Source = Methods.GetImageFromBytes(Product.Photo);
                    MessageBox.Show("Сохранено!");
                }
            }
            catch { MessageBox.Show("Вы выбрмли не изображение!"); }
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            Product.Photo = null;
            MyImage.Source = null;
        }
    }
}
