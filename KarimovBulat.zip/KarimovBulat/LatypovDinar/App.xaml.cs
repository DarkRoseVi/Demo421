﻿using LatypovDinar.Databases;
using System.Windows;

namespace LatypovDinar
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Demchik_Karimov_Bulat421Entities db = new Demchik_Karimov_Bulat421Entities();
    }
}
