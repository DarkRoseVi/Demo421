﻿using LatypovDinar.Databases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace LatypovDinar.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductList.xaml
    /// </summary>
    public partial class ProductList : Page
    {
        public ProductList()
        {
            InitializeComponent();
            Refresh();
        }
        private async void Refresh()
        {
            IEnumerable<Product> products = App.db.Product;

            if (!string.IsNullOrWhiteSpace(SearchTb.Text))
                products = products.Where(x => x.Title.ToLower().Contains(SearchTb.Text.ToLower()));

            MyList.ItemsSource = products.ToList();
        }

        private void SearchTb_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void AddBtn_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Navigation.NextPage(new AddEditProduct(new Product()));
        }

        private void Delete_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var pro = MyList.SelectedItem as Product;
            if (pro != null)
            {
                try
                {
                    App.db.Product.Remove(pro);
                    App.db.SaveChanges();
                    MessageBox.Show("Удалено! =)");
                    Refresh();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("нельяз удалить товар на него есть заказы!");
                }
            }
            else { MessageBox.Show("Выберите элемент!"); }
        }


        private void MyList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var pro = MyList.SelectedItem as Product;
            if (pro != null)
            {
                try
                {
                    Navigation.NextPage(new AddEditProduct(pro));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("нельяз удалить товар на него есть заказы!");
                }
            }
            else { MessageBox.Show("Выберите элемент!"); }
        }

        
    }
}
