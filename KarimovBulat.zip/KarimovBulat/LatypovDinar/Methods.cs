﻿using System.IO;
using System.Windows.Media.Imaging;

namespace LatypovDinar
{
    public static class Methods
    {
        public static BitmapImage GetImageFromBytes(byte[] bytes)
        {
            BitmapImage image = new BitmapImage();
            MemoryStream stream = new MemoryStream(bytes);

            image.BeginInit();
            image.StreamSource = stream;
            image.EndInit();
            return image;
        }
    }
}
