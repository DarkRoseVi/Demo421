﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Azaliya421exam
{
    public static class Navigation
    {
        public static Frame frame;
        public static void NextPage (Page page)
        {
            frame.Navigate(page);
        }
    }
}
