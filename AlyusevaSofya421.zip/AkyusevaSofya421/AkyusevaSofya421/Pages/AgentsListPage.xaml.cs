﻿using AkyusevaSofya421.Components;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkyusevaSofya421.Pages
{
    /// <summary>
    /// Логика взаимодействия для AgentsListPage.xaml
    /// </summary>
    public partial class AgentsListPage : Page
    {
        public AgentsListPage()
        {
            InitializeComponent();
            List<AgentType> atype = App.db.AgentType.ToList();
            atype = atype.Prepend(new AgentType() { Title = "Все типы", Image = "null" }).ToList();
            MessageBox.Show(atype.Count().ToString());
            FilterCbx.ItemsSource = atype.ToList();
            FilterCbx.DisplayMemberPath = "Title";
            Refresh();
        }

        public void Refresh()
        {
            AgentsWP.Children.Clear();
            PagesSP.Children.Clear();
            List<Agent> AgentsList = App.db.Agent.ToList();

            if (SearchTbx.Text.Trim().Length > 0) AgentsList = AgentsList.Where(x => x.Title.ToLower().Contains(SearchTbx.Text.ToLower())).ToList();

            switch (SortingCbx.SelectedIndex)
            {
                case 0:
                    AgentsList = AgentsList.OrderBy(x => x.Title).ToList();
                    break;

                case 1:
                    AgentsList = AgentsList.OrderBy(x => x.Discount).ToList();
                    break;

                case 2:
                    AgentsList = AgentsList.OrderBy(x => x.Priority).ToList();
                    break;

                case 3:
                    AgentsList = AgentsList.OrderByDescending(x => x.Title).ToList();
                    break;

                case 4:
                    AgentsList = AgentsList.OrderByDescending(x => x.Discount).ToList();
                    break;

                case 5:
                    AgentsList = AgentsList.OrderByDescending(x => x.Priority).ToList();
                    break;
            }

            if (FilterCbx.SelectedIndex > 0)
            {
                string title = (FilterCbx.Items[FilterCbx.SelectedIndex] as AgentType).Title;
                AgentsList = AgentsList.Where(x => x.AgentType.Title == title).ToList();
            }

            if (AgentsList.Count > 10)
            {
                int cunt = AgentsList.Count/10;
                if (AgentsList.Count%10 > 0) cunt ++;
                for (int i = 0; i < cunt; i++)
                {
                    Button butt = new Button() { Content = (i + 1).ToString(), Height = 40, Width = 40, };
                    butt.Click += (sender, e) => { PageButt_Click(sender, e); };
                    PagesSP.Children.Add(butt);
                }
                AgentsList = AgentsList.Skip(10*int.Parse(PageCurrentTb.Text)).Take(10).ToList();
            }

            foreach (Agent agent in AgentsList)
            {
                AgentsWP.Children.Add(new AgentUC(agent));
            }
        }

        private void PageButt_Click(object sender, RoutedEventArgs e)
        {
            PageCurrentTb.Text = (sender as Button).Content.ToString();
            Refresh();
        }

        private void BackButt_Click(object sender, RoutedEventArgs e)
        {
            if (PageCurrentTb.Text != "1")
            {
                PageCurrentTb.Text = (int.Parse(PageCurrentTb.Text)-1).ToString();
            }
            Refresh();
        }

        private void ForwardButt_Click(object sender, RoutedEventArgs e)
        {

            PageCurrentTb.Text = (int.Parse(PageCurrentTb.Text) + 1).ToString();
            Refresh();
        }

        private void SearchTbx_TextChanged(object sender, TextChangedEventArgs e)
        {
            PageCurrentTb.Text = "1";
            Refresh();
        }

        private void SortingCbx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            PageCurrentTb.Text = "1";
            Refresh();
        }

        private void FilterCbx_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            PageCurrentTb.Text = "1";
            Refresh();
        }

        //private void AddImageButt_Click(object sender, RoutedEventArgs e)
        //    {
        //        OpenFileDialog openFile = new OpenFileDialog()
        //        {
        //            Filter = "*.png|*.png|*.jpg|*.jpg|*.jepg|*.jepg"
        //        };
        //        if (openFile.ShowDialog().GetValueOrDefault())
        //        {
        //            product.Photo = File.ReadAllBytes(openFile.FileName);
        //            ProductImg.Source = new BitmapImage(new Uri(openFile.FileName));
        //            App.db.SaveChanges();
        //        }
        //        else MessageBox.Show("((((((((((");
        //        MemoryStream bytes = new
        //BitmapImage img = new
        //Img.BeginInit()
        //Img.Stream source= bytes
        //Img.EndInit()


        //OpenFileDialog file = new
        //{ Filter = "*.png|*.jpg" }
        //If (file.shoeDialig.getValue...irdeafult)
        //Image = File.ReadAllBytes(file.fileName)
        //Source = new BitmapImage(new uri(file.filename)))
    }
}
