﻿using AkyusevaSofya421.Components;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace AkyusevaSofya421
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static AlyusevaSofyaViktorovna421Entities db = new AlyusevaSofyaViktorovna421Entities();
    }
}
